Do you know that 65% of kids entering elementary school today, in the future will work for jobs that now do not even exist?

Where to start?
---------------

Your start should be from studying the basics of robotics, electronics and software engineering.
"Nanit" Robot  Education Kit is a robotics constructor that replaces 100 toys, by different assembly options. It has three training programs for children of different ages: for children 5-7 years old - learning the basics of robotics and electronics, learning about the world of robots; for children 8-10 years old - robot and games programming using Scratch language, children aged ten and over assemble a prototype of a SMART HOME on Arduino, program in C language. If you want a bright future for your child - contact us via the web-site - nanitrobot.com!

Where to start?
---------------
Your start should be from studying the basics of robotics, electronics and software engineering.
"Nanit" Robot  Education Kit is a robotics constructor that replaces 100 toys, by different assembly options. It has three training programs for children of different ages: for children 5-7 years old - learning the basics of robotics and electronics, learning about the world of robots; for children 8-10 years old - robot and games programming using Scratch language, children aged ten and over assemble a prototype of a SMART HOME on Arduino, program in C language. If you want a bright future for your child - contact us via the web-site - nanitrobot.com!