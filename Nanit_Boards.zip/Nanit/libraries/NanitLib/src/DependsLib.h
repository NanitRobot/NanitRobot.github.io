/**
 * @author Sam4uk
 * @date 23-03-23
 * @details Інклюди бібілотек третіх сторін
*/
#ifndef _DEPENDS_LIB_H_
#define _DEPENDS_LIB_H_
#include <FastLED_NeoPixel.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#endif